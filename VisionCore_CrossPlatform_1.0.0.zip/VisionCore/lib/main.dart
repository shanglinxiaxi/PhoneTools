import 'package:flutter/material.dart';
import 'ui/home_page.dart';


void main() => runApp(const VisionCoreApp());

class VisionCoreApp extends StatelessWidget {
  const VisionCoreApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'VisionCore',
    theme: ThemeData(colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF65C58A), brightness: Brightness.dark), useMaterial3: true),
    home: const HomePage(),
  );
}
