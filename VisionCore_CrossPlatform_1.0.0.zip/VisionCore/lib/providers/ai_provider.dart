import 'dart:convert';
import 'dart:typed_data';
import 'package:http/http.dart' as http;

class AiVisionProvider {
  Future<String> analyzeImage(Uint8List bytes, {required String endpoint, required String apiKey, required String model, required String prompt}) async {
    if (endpoint.trim().isEmpty || apiKey.trim().isEmpty || model.trim().isEmpty) {
      throw StateError('请先配置 API 地址、密钥和模型。');
    }
    final uri = Uri.tryParse(endpoint.trim());
    if (uri == null || !uri.hasScheme || !uri.hasAuthority) throw ArgumentError('API 地址格式无效。');
    final payload = {
      'model': model.trim(),
      'messages': [
        {'role': 'user', 'content': [
          {'type': 'text', 'text': prompt},
          {'type': 'image_url', 'image_url': {'url': 'data:image/jpeg;base64,${base64Encode(bytes)}'}}
        ]}
      ],
      'temperature': 0.2,
    };
    final response = await http.post(uri,
      headers: {'Content-Type': 'application/json', 'Authorization': 'Bearer ${apiKey.trim()}'},
      body: jsonEncode(payload)).timeout(const Duration(seconds: 90));
    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw Exception('API HTTP ${response.statusCode}: ${_short(response.body)}');
    }
    final decoded = jsonDecode(response.body);
    final content = decoded['choices']?[0]?['message']?['content'];
    if (content is String && content.trim().isNotEmpty) return content.trim();
    if (content is List) return content.map((v) => v['text'] ?? '').join('\n').trim();
    throw FormatException('API 返回格式无法识别。');
  }
  String _short(String text) => text.length > 500 ? '${text.substring(0, 500)}…' : text;
}
