enum Comparison { greaterThan, greaterOrEqual, equal, lessOrEqual, lessThan }
class ThresholdRule {
  final String name;
  final double threshold;
  final Comparison comparison;
  final String note;
  const ThresholdRule({required this.name, required this.threshold, required this.comparison, required this.note});
  bool evaluate(double value) => switch (comparison) {
    Comparison.greaterThan => value > threshold,
    Comparison.greaterOrEqual => value >= threshold,
    Comparison.equal => value == threshold,
    Comparison.lessOrEqual => value <= threshold,
    Comparison.lessThan => value < threshold,
  };
  String get expression => switch (comparison) {
    Comparison.greaterThan => '>', Comparison.greaterOrEqual => '>=', Comparison.equal => '==',
    Comparison.lessOrEqual => '<=', Comparison.lessThan => '<'
  };
}
