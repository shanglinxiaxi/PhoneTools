import 'dart:typed_data';

class AnalysisResult {
  final String summary;
  final Map<String, String> detectedText;
  final DateTime createdAt;
  const AnalysisResult({required this.summary, required this.detectedText, required this.createdAt});
}

abstract interface class VisualAnalyzer {
  Future<AnalysisResult> analyze(Uint8List imageBytes);
}
