class SessionLogEntry {
  final DateTime time;
  final String category;
  final String message;
  const SessionLogEntry({required this.time, required this.category, required this.message});
  factory SessionLogEntry.now(String category, String message) => SessionLogEntry(time: DateTime.now(), category: category, message: message);
  Map<String, dynamic> toJson() => {'time': time.toIso8601String(), 'category': category, 'message': message};
  factory SessionLogEntry.fromJson(Map<String, dynamic> json) => SessionLogEntry(time: DateTime.parse(json['time']), category: json['category'], message: json['message']);
}
