import 'package:flutter_test/flutter_test.dart';
import 'package:vision_core/core/rules.dart';

void main() {
  test('threshold comparisons behave correctly', () {
    expect(const ThresholdRule(name: 'x', threshold: 5, comparison: Comparison.greaterThan, note: '').evaluate(6), true);
    expect(const ThresholdRule(name: 'x', threshold: 5, comparison: Comparison.greaterOrEqual, note: '').evaluate(5), true);
    expect(const ThresholdRule(name: 'x', threshold: 5, comparison: Comparison.equal, note: '').evaluate(5), true);
    expect(const ThresholdRule(name: 'x', threshold: 5, comparison: Comparison.lessOrEqual, note: '').evaluate(4), true);
    expect(const ThresholdRule(name: 'x', threshold: 5, comparison: Comparison.lessThan, note: '').evaluate(4), true);
  });
}
