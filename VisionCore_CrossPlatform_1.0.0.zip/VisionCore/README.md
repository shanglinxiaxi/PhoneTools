# VisionCore 1.0.0

Cross-platform visual analysis workspace (Flutter): image import, image preview, configurable OpenAI-compatible multimodal endpoint, prompt-based image analysis, and in-session log view/export as JSON text. No gameplay automation, macro, touch execution, route, or game-specific modules.


## Targets
Flutter targets: Android, iOS, Windows, macOS, Linux, Web. Actual build/test matrix has not yet been run in this environment.

## Build
Install Flutter SDK, then:
```sh
flutter pub get
flutter analyze
flutter test
flutter run
```
Platform builds:
```sh
flutter build apk
flutter build appbundle
flutter build ios
flutter build windows
flutter build macos
flutter build linux
flutter build web
```

## Use
1. Import an image.
2. Open Settings and configure an OpenAI-compatible chat-completions endpoint, model, and API key.
3. Edit the vision prompt as needed.
4. Analyze. The selected image is sent to the configured endpoint as a base64 image data URL.
5. Session log stores analysis metadata/errors in memory for the current session and can display JSON.

**Privacy:** API key is kept in memory only and not saved. Endpoint/model/prompt are saved locally in preferences. Image bytes are sent to the API you configure when you press Analyze. Do not send sensitive images to an untrusted endpoint.

## Limitations
- Image import is implemented; universal cross-platform whole-screen capture is not implemented because capture APIs/permissions differ by OS.
- Local OCR/vision model is not bundled; AI analysis requires a compatible endpoint and network access.
- Logs are session-only; JSON is displayed for manual copying, not automatically written to a file.
- API compatibility varies by provider, especially image payload support.
- Builds, static analysis, and physical-device tests are pending; Flutter SDK was not available at package-generation time.

## Architecture
- `lib/ui/home_page.dart`: UI, import, configuration, orchestration.
- `lib/providers/ai_provider.dart`: HTTP multimodal API adapter.
- `lib/core/rules.dart`: reusable numeric threshold rule model.
- `lib/core/session_log.dart`: session log data model.
